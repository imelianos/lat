package AESimualtor;

interface Comparable {
	
	boolean lessThan(Comparable y);
	
}