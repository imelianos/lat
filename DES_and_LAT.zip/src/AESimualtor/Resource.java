package AESimualtor;

abstract class Resource extends AbstractResource {
	
    double time;
    
    int id;
    
}