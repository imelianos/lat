package AESimualtor;

public class Entity implements Constants {
	
    double time;

    int id;
    
    EntityTypes entityType;
	
}
